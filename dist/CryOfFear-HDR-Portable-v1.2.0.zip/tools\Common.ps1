<#
.SYNOPSIS
    Shared helpers for the Cry of Fear HDR portable installer.
#>

function Find-CryOfFear {
    $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
    if (-not $steam) { return $null }

    $libraries = @($steam)
    $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
        Select-String -Path $vdf -Pattern '"path"\s+"([^"]+)"' -AllMatches |
            ForEach-Object { $_.Matches } |
            ForEach-Object { $libraries += $_.Groups[1].Value -replace '\\\\', '\' }
    }

    foreach ($lib in ($libraries | Select-Object -Unique)) {
        $candidate = Join-Path $lib 'steamapps\common\Cry of Fear'
        if (Test-Path (Join-Path $candidate 'cof.exe')) { return $candidate }
    }
    return $null
}

function Get-LaunchOptions {
    param(
        [int] $Width,
        [int] $Height,
        [switch] $Windowed
    )
    $mode = if ($Windowed) { "-window -w $Width -h $Height" } else { "-fullscreen -w $Width -h $Height" }
    return "$mode -noforcemparms -noforcemaccel -noforcemspd"
}

function Import-NvidiaProfile {
    param(
        [string] $InspectorPath,
        [string] $NipPath
    )

    if (-not (Test-Path $InspectorPath)) {
        Write-Host "   [warn] NVIDIA Profile Inspector not found: $InspectorPath" -ForegroundColor Yellow
        return $false
    }
    if (-not (Test-Path $NipPath)) {
        Write-Host "   [warn] Profile missing: $NipPath" -ForegroundColor Yellow
        return $false
    }

    try {
        $proc = Start-Process -FilePath $InspectorPath -ArgumentList @('-silentImport', $NipPath) -Verb RunAs -PassThru -Wait
        if (-not $proc) {
            Write-Host '   [warn] UAC cancelled or inspector did not start - driver profile not imported.' -ForegroundColor Yellow
            return $false
        }
        if ($proc.ExitCode -ne 0) {
            Write-Host "   [warn] Profile Inspector exited with code $($proc.ExitCode)." -ForegroundColor Yellow
            return $false
        }
        Write-Host '   [ok]   NVIDIA driver profile imported' -ForegroundColor Green
        return $true
    } catch {
        Write-Host "   [warn] Profile import failed: $($_.Exception.Message)" -ForegroundColor Yellow
        return $false
    }
}

function Set-PerAppAutoHdrOff {
    param([string] $ExePath)

    $key = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    if (-not (Test-Path $key)) {
        New-Item -Path $key -Force | Out-Null
    }

    $existing = (Get-ItemProperty -Path $key -Name $ExePath -ErrorAction SilentlyContinue).$ExePath
    $parts = @()
    if ($existing) {
        $parts = @($existing -split ';' | Where-Object { $_ -and ($_ -notmatch '^\s*AutoHDREnable\s*=') })
    }
    $parts += 'AutoHDREnable=0'
    $value = (($parts | Where-Object { $_ }) -join ';').Trim(';') + ';'
    Set-ItemProperty -Path $key -Name $ExePath -Value $value
    return $value
}

function Reset-PerAppAutoHdr {
    param([string] $ExePath)

    $key = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    $existing = (Get-ItemProperty -Path $key -Name $ExePath -ErrorAction SilentlyContinue).$ExePath
    if (-not $existing) { return $null }

    $parts = @($existing -split ';' | Where-Object { $_ -and ($_ -notmatch '^\s*AutoHDREnable\s*=') })
    if ($parts.Count -eq 0) {
        Remove-ItemProperty -Path $key -Name $ExePath -Force
        return ''
    }
    $value = ($parts -join ';').Trim(';') + ';'
    Set-ItemProperty -Path $key -Name $ExePath -Value $value
    return $value
}

function Initialize-HdrProbeType {
    if ('CofHdrProbe' -as [type]) { return $true }
    try {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CofHdrProbe
{
    [StructLayout(LayoutKind.Sequential)] public struct LUID { public uint Low; public int High; }
    [StructLayout(LayoutKind.Sequential)] public struct SOURCE { public LUID adapterId; public uint id; public uint modeInfoIdx; public uint statusFlags; }
    [StructLayout(LayoutKind.Sequential)] public struct RATIONAL { public uint num; public uint den; }
    [StructLayout(LayoutKind.Sequential)] public struct TARGET {
        public LUID adapterId; public uint id; public uint modeInfoIdx;
        public uint outputTechnology; public uint rotation; public uint scaling;
        public RATIONAL refreshRate; public uint scanLineOrdering;
        public int targetAvailable; public uint statusFlags; }
    [StructLayout(LayoutKind.Sequential)] public struct PATH { public SOURCE sourceInfo; public TARGET targetInfo; public uint flags; }
    [StructLayout(LayoutKind.Sequential)] public struct MODE { public uint infoType; public uint id; public LUID adapterId;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 48)] public byte[] blob; }
    [StructLayout(LayoutKind.Sequential)] public struct HEADER { public uint type; public uint size; public LUID adapterId; public uint id; }
    [StructLayout(LayoutKind.Sequential)] public struct GET_COLOR { public HEADER header; public uint value; public uint colorEncoding; public uint bitsPerColorChannel; }

    [DllImport("user32.dll")] static extern int GetDisplayConfigBufferSizes(uint flags, out uint numPath, out uint numMode);
    [DllImport("user32.dll")] static extern int QueryDisplayConfig(uint flags, ref uint numPath, [Out] PATH[] paths, ref uint numMode, [Out] MODE[] modes, IntPtr topo);
    [DllImport("user32.dll")] static extern int DisplayConfigGetDeviceInfo(ref GET_COLOR info);

    static string Tech(uint t)
    {
        switch (t) {
            case 4:  return "DVI";
            case 5:  return "HDMI";
            case 10: return "DisplayPort";
            case 11: return "intern";
            case 0x80000000: return "intern";
            default: return "Typ " + t;
        }
    }

    public static string[] Probe()
    {
        uint np, nm;
        if (GetDisplayConfigBufferSizes(2, out np, out nm) != 0) return new string[0];
        PATH[] paths = new PATH[np]; MODE[] modes = new MODE[nm];
        if (QueryDisplayConfig(2, ref np, paths, ref nm, modes, IntPtr.Zero) != 0) return new string[0];
        string[] outp = new string[np];
        for (int i = 0; i < np; i++) {
            var t = paths[i].targetInfo;
            GET_COLOR g = new GET_COLOR();
            g.header.type = 9;
            g.header.size = (uint)Marshal.SizeOf(typeof(GET_COLOR));
            g.header.adapterId = t.adapterId;
            g.header.id = t.id;
            if (DisplayConfigGetDeviceInfo(ref g) != 0) { outp[i] = Tech(t.outputTechnology) + "|?|?|?"; continue; }
            outp[i] = Tech(t.outputTechnology) + "|" + ((g.value & 1) != 0) + "|" + ((g.value & 2) != 0) + "|" + g.bitsPerColorChannel;
        }
        return outp;
    }
}
'@
        return $true
    } catch {
        return $false
    }
}

function Get-DisplayHdrStatus {
    $result = [pscustomobject]@{
        Queried = $false
        AnyOn   = $false
        Rows    = @()
    }
    if (-not (Initialize-HdrProbeType)) { return $result }
    try {
        $probe = [CofHdrProbe]::Probe()
        if (-not $probe -or $probe.Count -eq 0) { return $result }
        $result.Queried = $true
        foreach ($row in $probe) {
            $f = $row -split '\|'
            $on = $f.Count -gt 2 -and $f[2] -eq 'True'
            $sup = $f.Count -gt 1 -and $f[1] -eq 'True'
            $item = [pscustomobject]@{
                Tech      = $f[0]
                Supported = $sup
                On        = $on
                Bpc       = if ($f.Count -gt 3) { $f[3] } else { '?' }
            }
            $result.Rows += $item
            if ($on) { $result.AnyOn = $true }
        }
    } catch {}
    return $result
}

function Set-CvarInText {
    param(
        [string] $Text,
        [string] $Name,
        [string] $Value
    )
    $escaped = [regex]::Escape($Name)
    $pattern = "(?m)^(\s*)$escaped(\s+)\S+.*$"
    if ([regex]::IsMatch($Text, "(?m)^\s*$escaped\s+\S+")) {
        return [regex]::Replace($Text, $pattern, "`${1}$Name`${2}$Value", 1)
    }
    $nl = if ($Text -match "`r`n") { "`r`n" } else { "`n" }
    return $Text.TrimEnd() + "$nl$Name $Value$nl"
}

function Merge-Autoexec {
    param(
        [string] $TemplatePath,
        [string] $DestinationPath,
        [double] $Fov,
        [bool] $RawMouse,
        [bool] $LowLatencyVsync,
        [bool] $EngineRates
    )

    $template = Get-Content -Path $TemplatePath -Raw
    $template = $template -replace '(?m)^cl_fovmultiplier\s+[0-9.]+', ("cl_fovmultiplier {0:F2}" -f $Fov)

    $cvars = [ordered]@{
        'gl_renderer'      = '1'
        'gl_twopassdyn'    = '1'
        'brightness'       = '1'
        'gamma'            = '2.5'
        'gl_brightness'    = '0'
        'gl_gamma'         = '1'
        'gl_posteffects'   = '1'
        'gl_texturemode'   = 'gl_linear_mipmap_linear'
        'cl_fovmultiplier' = ('{0:F2}' -f $Fov)
        'fps_max'          = '100'
        'developer'        = '0'
    }
    if ($RawMouse) { $cvars['m_filter'] = '0' }
    if ($LowLatencyVsync) { $cvars['gl_vsync'] = '0' }
    if ($EngineRates) {
        $cvars['cl_cmdrate'] = '101'
        $cvars['cl_updaterate'] = '101'
        $cvars['rate'] = '100000'
    }

    if (-not (Test-Path $DestinationPath)) {
        $out = $template
        if (-not $RawMouse) { $out = [regex]::Replace($out, '(?m)^\s*m_filter\s+\S+.*\r?\n?', '') }
        if (-not $LowLatencyVsync) { $out = [regex]::Replace($out, '(?m)^\s*gl_vsync\s+\S+.*\r?\n?', '') }
        if (-not $EngineRates) {
            $out = [regex]::Replace($out, '(?m)^\s*cl_cmdrate\s+\S+.*\r?\n?', '')
            $out = [regex]::Replace($out, '(?m)^\s*cl_updaterate\s+\S+.*\r?\n?', '')
            $out = [regex]::Replace($out, '(?m)^\s*rate\s+\S+.*\r?\n?', '')
        }
        Set-Content -Path $DestinationPath -Value $out -Encoding ASCII -NoNewline
        return 'created'
    }

    $existing = Get-Content -Path $DestinationPath -Raw
    foreach ($name in $cvars.Keys) {
        $existing = Set-CvarInText -Text $existing -Name $name -Value $cvars[$name]
    }
    Set-Content -Path $DestinationPath -Value $existing -Encoding ASCII -NoNewline
    return 'merged'
}
