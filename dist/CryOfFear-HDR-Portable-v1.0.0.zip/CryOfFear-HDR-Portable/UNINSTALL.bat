@echo off
setlocal
title Cry of Fear HDR - Uninstaller
cd /d "%~dp0"

echo ==============================================================================
echo   CRY OF FEAR: REVERT TO VANILLA
echo ==============================================================================
echo.
echo Restoring original files and resetting driver profile...
echo If prompted by Windows User Account Control (UAC), please click YES.
echo.

powershell -ExecutionPolicy Bypass -Command "Start-Process powershell -ArgumentList '-ExecutionPolicy Bypass -NoProfile -File """%~dp0tools\Uninstall.ps1"""' -Verb runas -Wait"

echo.
pause
