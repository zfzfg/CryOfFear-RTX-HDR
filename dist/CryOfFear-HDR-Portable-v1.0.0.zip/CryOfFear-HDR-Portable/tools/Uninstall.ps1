<#
.SYNOPSIS
    Reverts Cry of Fear HDR & 1440p Mod back to stock.
    Part of CryOfFear-HDR-Portable by Collin Lerche (zfzfg) | STERRA.
#>
[CmdletBinding()]
param(
    [string] $GamePath
)

$ErrorActionPreference = 'Stop'
$scriptRoot = $PSScriptRoot
$pkgRoot = Split-Path -Parent $scriptRoot

function Write-Step { param($m) Write-Host "`n== $m" -ForegroundColor Cyan }
function Write-Ok   { param($m) Write-Host "   [ok]   $m" -ForegroundColor Green }
function Write-Warn { param($m) Write-Host "   [warn] $m" -ForegroundColor Yellow }

function Find-CryOfFear {
    $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
    if (-not $steam) { return $null }

    $libraries = @($steam)
    $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
        Select-String -Path $vdf -Pattern '"path"\s+"([^"]+)"' -AllMatches |
            ForEach-Object { $_.Matches } |
            ForEach-Object { $libraries += $_.Groups[1].Value -replace '\\\\', '\' }
    }

    foreach ($lib in ($libraries | Select-Object -Unique)) {
        $candidate = Join-Path $lib 'steamapps\common\Cry of Fear'
        if (Test-Path (Join-Path $candidate 'cof.exe')) { return $candidate }
    }
    return $null
}

Write-Step 'Locating Cry of Fear'
if (-not $GamePath) { $GamePath = Find-CryOfFear }
if (-not $GamePath -or -not (Test-Path (Join-Path $GamePath 'cof.exe'))) {
    throw "Cry of Fear could not be located automatically."
}
$exe    = Join-Path $GamePath 'cof.exe'
$modDir = Join-Path $GamePath 'cryoffear'
Write-Ok "Found game at: $GamePath"

Write-Step 'Restoring files from pristine backup'
$backupDir = Join-Path $pkgRoot 'backup\original'
if (Test-Path $backupDir) {
    foreach ($item in @('autoexec.cfg', 'config.cfg', 'scriptsettings.dat')) {
        $src = Join-Path $backupDir $item
        if (Test-Path $src) {
            Copy-Item $src -Destination $modDir -Force
            Write-Ok "Restored $item"
        }
    }
    $shaderBak = Join-Path $backupDir 'cgshaders\black_fp.cg'
    if (Test-Path $shaderBak) {
        Copy-Item $shaderBak -Destination (Join-Path $modDir 'cgshaders\black_fp.cg') -Force
        Write-Ok "Restored cgshaders/black_fp.cg"
    }
} else {
    Write-Warn "No backup folder found. Verifying files via Steam will restore stock state."
}

Write-Step 'Removing High-DPI override'
$layers = 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers'
$existing = (Get-ItemProperty -Path $layers -Name $exe -ErrorAction SilentlyContinue).$exe
if ($existing) {
    $remaining = ($existing -split '\s+' | Where-Object { $_ -and $_ -ne 'HIGHDPIAWARE' -and $_ -ne '~' }) -join ' '
    if ($remaining) {
        Set-ItemProperty -Path $layers -Name $exe -Value "~ $remaining"
        Write-Ok "Kept other flags: $remaining"
    } else {
        Remove-ItemProperty -Path $layers -Name $exe -Force
        Write-Ok 'High-DPI override removed'
    }
}

Write-Step 'Resetting NVIDIA driver profile'
$inspector = Join-Path $scriptRoot 'nvidiaProfileInspector\nvidiaProfileInspector.exe'
$resetNip = Join-Path $pkgRoot 'profiles\CryOfFear-HDR-Reset.nip'
if (Test-Path $inspector -and (Test-Path $resetNip)) {
    Start-Process -FilePath $inspector -ArgumentList '-silentImport', "`"$resetNip`"" -Verb runas -Wait
    Write-Ok 'Driver profile reset to default'
}

Write-Step 'Uninstallation Complete!'
Write-Host "`nCry of Fear has been restored back to its vanilla state.`n" -ForegroundColor Green
