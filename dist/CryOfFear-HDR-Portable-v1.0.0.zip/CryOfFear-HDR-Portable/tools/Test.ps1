<#
.SYNOPSIS
    Diagnostics & Health Check for Cry of Fear HDR & 1440p Mod.
    Part of CryOfFear-HDR-Portable by Collin Lerche (zfzfg) | STERRA.
#>
[CmdletBinding()]
param(
    [string] $GamePath
)

function Head { param($m) Write-Host "`n--- $m" -ForegroundColor Cyan }
function Pass { param($m) Write-Host "   [PASS] $m" -ForegroundColor Green }
function Warn { param($m) Write-Host "   [WARN] $m" -ForegroundColor Yellow }
function Fail { param($m) Write-Host "   [FAIL] $m" -ForegroundColor Red }
function Info { param($m) Write-Host "   [INFO] $m" -ForegroundColor Gray }

# --- 1. GPU and OS ----------------------------------------------------------
Head 'GPU and OS'
$gpu = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue |
       Where-Object { $_.Name -like '*NVIDIA*' } | Select-Object -First 1
if ($gpu) {
    Pass "$($gpu.Name), driver $($gpu.DriverVersion)"
    if ($gpu.Name -match 'RTX') { Pass 'NVIDIA RTX hardware detected (supports RTX HDR)' }
    else { Warn 'Non-RTX GPU detected. RTX HDR requires an RTX series card.' }
} else { Fail 'No NVIDIA GPU detected.' }

$os = [System.Environment]::OSVersion
Pass "Windows build $($os.Version.Build)"

# --- 2. Display HDR ---------------------------------------------------------
Head 'Display HDR'
try {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class DispCheck {
    [DllImport("user32.dll")]
    public static extern int GetDisplayConfigBufferSizes(uint flags, out uint numPathArrayElements, out uint numModeInfoArrayElements);
}
'@ -ErrorAction SilentlyContinue
} catch {}

$mode = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue |
        Where-Object { $_.CurrentHorizontalResolution } | Select-Object -First 1
if ($mode) {
    Pass "Desktop Resolution: $($mode.CurrentHorizontalResolution)x$($mode.CurrentVerticalResolution) @ $($mode.CurrentRefreshRate) Hz"
}

# --- 3. Game Install --------------------------------------------------------
Head 'Game Install'
function Find-CryOfFear {
    $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
    if (-not $steam) { return $null }
    $libraries = @($steam)
    $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
        Select-String -Path $vdf -Pattern '"path"\s+"([^"]+)"' -AllMatches |
            ForEach-Object { $_.Matches } |
            ForEach-Object { $libraries += $_.Groups[1].Value -replace '\\\\', '\' }
    }
    foreach ($lib in ($libraries | Select-Object -Unique)) {
        $candidate = Join-Path $lib 'steamapps\common\Cry of Fear'
        if (Test-Path (Join-Path $candidate 'cof.exe')) { return $candidate }
    }
    return $null
}

if (-not $GamePath) { $GamePath = Find-CryOfFear }
if ($GamePath -and (Test-Path (Join-Path $GamePath 'cof.exe'))) {
    Pass "Game executable found at: $GamePath"
    $opengl = Join-Path $GamePath 'opengl32.dll'
    if (Test-Path $opengl) {
        Pass 'Paranoia custom OpenGL renderer is present (opengl32.dll)'
    } else {
        Fail 'Missing opengl32.dll! Game will fall back to software rendering without HDR highlights.'
    }
} else {
    Fail 'Cry of Fear was not found on this system.'
}

# --- 4. Game Configuration --------------------------------------------------
Head 'Game Configuration (autoexec.cfg)'
$cfg = Join-Path $GamePath 'cryoffear\autoexec.cfg'
if (Test-Path $cfg) {
    $text = Get-Content $cfg -Raw
    if ($text -match 'gl_renderer\s+1') { Pass 'Paranoia dynamic lighting renderer enabled (gl_renderer 1)' }
    else { Fail 'gl_renderer 1 missing in autoexec.cfg' }

    if ($text -match 'cl_fovmultiplier\s+([0-9.]+)') { Pass "Field of View multiplier set to $($Matches[1])" }
    if ($text -match 'm_filter\s+0') { Pass 'Direct raw mouse input active (m_filter 0)' }
    if ($text -match 'gl_vsync\s+0') { Pass 'Ultra-low latency VRR sync active (gl_vsync 0)' }
    if ($text -match 'fps_max\s+100') { Pass 'Engine framerate capped at 100 FPS (engine limit)' }
} else {
    Warn 'autoexec.cfg not found in game directory.'
}

# --- 5. High-DPI Override ---------------------------------------------------
Head 'High-DPI Override'
$exe = Join-Path $GamePath 'cof.exe'
$layers = 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers'
$dpi = (Get-ItemProperty -Path $layers -Name $exe -ErrorAction SilentlyContinue).$exe
if ($dpi -match 'HIGHDPIAWARE') { Pass 'Application-controlled DPI scaling active (HIGHDPIAWARE)' }
else { Warn 'HIGHDPIAWARE not active for cof.exe.' }

# --- 6. Registry Settings ---------------------------------------------------
Head 'Game Registry Settings'
$reg = Get-ItemProperty -Path 'HKCU:\Software\Valve\Cry of Fear\Settings' -ErrorAction SilentlyContinue
if ($reg) {
    Pass "Configured Resolution: $($reg.ScreenWidth)x$($reg.ScreenHeight)"
    Pass "Display Mode: $(if ($reg.SCREENWINDOWED -eq 1) { 'Windowed' } else { 'Fullscreen' })"
}

# --- 7. NVIDIA Driver Profile -----------------------------------------------
Head 'NVIDIA Driver Profile'
$drs = Join-Path $env:ProgramData 'NVIDIA Corporation\Drs\nvdrsdb0.bin'
if (Test-Path $drs) {
    try {
        $bytes = [System.IO.File]::ReadAllBytes($drs)
        $haystack = [System.Text.Encoding]::Unicode.GetString($bytes)
        if ($haystack.Contains('Cry of Fear (HDR)')) {
            Pass 'Profile "Cry of Fear (HDR)" found in NVIDIA driver database'

            $nameBytes = [Text.Encoding]::Unicode.GetBytes("Cry of Fear (HDR)`0")
            $at = -1
            for ($i = 0; $i -le $bytes.Length - $nameBytes.Length; $i++) {
                $hit = $true
                for ($j = 0; $j -lt $nameBytes.Length; $j++) {
                    if ($bytes[$i + $j] -ne $nameBytes[$j]) { $hit = $false; break }
                }
                if ($hit) { $at = $i; break }
            }
            $settings = @{}
            if ($at -gt 0) {
                $r = $at - 16
                while ($r -ge 0 -and $bytes[$r] -eq 0xA4 -and $bytes[$r+1] -eq 0x00 -and
                       $bytes[$r+2] -eq 0x10 -and $bytes[$r+3] -eq 0x00) {
                    $id  = [BitConverter]::ToUInt32($bytes, $r + 4)
                    $val = [BitConverter]::ToUInt32($bytes, $r + 12)
                    $settings[$id] = $val
                    $r -= 16
                }
            }
            Pass "$($settings.Count) settings active in driver profile"
            if ($settings[[uint32]0x20D690F8] -eq 1) { Pass 'Present method = Layered on DXGI swapchain (HDR enabled)' }
            if ($settings[[uint32]0x00DD48FB] -eq 1) { Pass 'RTX HDR = Enabled' }
            if ($settings[[uint32]0x101E61A9]) { Pass "Anisotropic filtering = $($settings[[uint32]0x101E61A9])x" }
            if ($settings[[uint32]0x107EFC5B] -eq 0) { Pass 'MSAA driver override = Off (Crash-safe)' }
        } else {
            Warn 'Profile "Cry of Fear (HDR)" not found in driver database. Please run the installer.'
        }
    } catch {
        Warn 'Could not read driver database.'
    }
}
Write-Host "`nDiagnostic complete.`n" -ForegroundColor Cyan
