<#
.SYNOPSIS
    Installs the Cry of Fear HDR & 1440p Enhancement Mod.
    Part of CryOfFear-HDR-Portable by Collin Lerche (zfzfg) | STERRA.
#>
[CmdletBinding()]
param(
    [string] $GamePath,
    [double] $Fov = 1.15,
    [int]    $Width = 0,
    [int]    $Height = 0,
    [switch] $Windowed,
    [switch] $Shader,
    [switch] $SkipProfile
)

$ErrorActionPreference = 'Stop'
$scriptRoot = $PSScriptRoot
$pkgRoot = Split-Path -Parent $scriptRoot

function Write-Step { param($m) Write-Host "`n== $m" -ForegroundColor Cyan }
function Write-Ok   { param($m) Write-Host "   [ok]   $m" -ForegroundColor Green }
function Write-Warn { param($m) Write-Host "   [warn] $m" -ForegroundColor Yellow }

# --- 1. Locate the game -----------------------------------------------------
function Find-CryOfFear {
    $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
    if (-not $steam) { return $null }

    $libraries = @($steam)
    $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
        Select-String -Path $vdf -Pattern '"path"\s+"([^"]+)"' -AllMatches |
            ForEach-Object { $_.Matches } |
            ForEach-Object { $libraries += $_.Groups[1].Value -replace '\\\\', '\' }
    }

    foreach ($lib in ($libraries | Select-Object -Unique)) {
        $candidate = Join-Path $lib 'steamapps\common\Cry of Fear'
        if (Test-Path (Join-Path $candidate 'cof.exe')) { return $candidate }
    }
    return $null
}

Write-Step 'Locating Cry of Fear'
if (-not $GamePath) { $GamePath = Find-CryOfFear }
if (-not $GamePath -or -not (Test-Path (Join-Path $GamePath 'cof.exe'))) {
    throw "Cry of Fear could not be located automatically. Please provide -GamePath '<path to Cry of Fear folder>'."
}
$exe    = Join-Path $GamePath 'cof.exe'
$modDir = Join-Path $GamePath 'cryoffear'
Write-Ok "Found game at: $GamePath"

# --- 2. Back up original files ----------------------------------------------
Write-Step 'Backing up game files'
$backupDir = Join-Path $pkgRoot 'backup\original'
if (-not (Test-Path $backupDir)) {
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    foreach ($item in @('autoexec.cfg', 'config.cfg', 'scriptsettings.dat')) {
        $src = Join-Path $modDir $item
        if (Test-Path $src) {
            Copy-Item $src -Destination $backupDir -Force
            Write-Ok "Backed up $item"
        }
    }
    $shaderSrc = Join-Path $modDir 'cgshaders\black_fp.cg'
    if (Test-Path $shaderSrc) {
        $shaderBakDir = Join-Path $backupDir 'cgshaders'
        New-Item -ItemType Directory -Path $shaderBakDir -Force | Out-Null
        Copy-Item $shaderSrc -Destination $shaderBakDir -Force
        Write-Ok 'Backed up cgshaders/black_fp.cg'
    }
} else {
    Write-Ok "Pristine backup already preserved at $backupDir"
}

# --- 3. Install autoexec.cfg ------------------------------------------------
Write-Step 'Deploying tuned autoexec.cfg'
$srcCfg = Join-Path $pkgRoot 'files\autoexec.cfg'
$dstCfg = Join-Path $modDir 'autoexec.cfg'
if (-not (Test-Path $srcCfg)) { throw "Missing template: $srcCfg" }

$cfgText = Get-Content -Path $srcCfg -Raw
if ($Fov -gt 0) {
    $cfgText = $cfgText -replace '(?m)^cl_fovmultiplier\s+[0-9.]+', "cl_fovmultiplier $Fov"
    Write-Ok "Field of View set to $Fov (~$([math]::Round($Fov * 90, 0))°)"
}

Set-Content -Path $dstCfg -Value $cfgText -Encoding ASCII -NoNewline
Write-Ok "Installed $dstCfg"

# --- 4. High-DPI Override ---------------------------------------------------
Write-Step 'Setting High-DPI override for cof.exe'
$layers = 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers'
if (-not (Test-Path $layers)) { New-Item -Path $layers -Force | Out-Null }
$existing = (Get-ItemProperty -Path $layers -Name $exe -ErrorAction SilentlyContinue).$exe
if ($existing -and $existing -notmatch 'HIGHDPIAWARE') {
    Set-ItemProperty -Path $layers -Name $exe -Value "$existing HIGHDPIAWARE"
} elseif (-not $existing) {
    Set-ItemProperty -Path $layers -Name $exe -Value '~ HIGHDPIAWARE'
}
Write-Ok 'Application-controlled DPI scaling enabled'

# --- 5. Game Registry Configuration -----------------------------------------
Write-Step 'Configuring display resolution & mode in registry'
if ($Width -le 0 -or $Height -le 0) {
    $mode = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue |
            Where-Object { $_.CurrentHorizontalResolution } | Select-Object -First 1
    if ($mode) {
        $Width  = [int]$mode.CurrentHorizontalResolution
        $Height = [int]$mode.CurrentVerticalResolution
    } else {
        $Width  = 2560
        $Height = 1440
    }
}

$regKey = 'HKCU:\Software\Valve\Cry of Fear\Settings'
if (-not (Test-Path $regKey)) { New-Item -Path $regKey -Force | Out-Null }
Set-ItemProperty -Path $regKey -Name 'ScreenWidth' -Value $Width
Set-ItemProperty -Path $regKey -Name 'ScreenHeight' -Value $Height
Set-ItemProperty -Path $regKey -Name 'SCREENWINDOWED' -Value (if ($Windowed) { 1 } else { 0 })
Write-Ok "Resolution set to: ${Width}x${Height} (Mode: $(if ($Windowed) { 'Windowed' } else { 'Native Borderless Fullscreen' }))"

# --- 6. Optional: Softened Nightmare Shader ---------------------------------
if ($Shader) {
    Write-Step 'Installing softened black_fp.cg shader'
    $shaderSrc = Join-Path $pkgRoot 'files\cgshaders\black_fp.cg'
    $shaderDst = Join-Path $modDir 'cgshaders\black_fp.cg'
    if (Test-Path $shaderSrc) {
        Copy-Item -Path $shaderSrc -Destination $shaderDst -Force
        Write-Ok "Installed $shaderDst"
    }
}

# --- 7. NVIDIA Driver Profile Import ----------------------------------------
if (-not $SkipProfile) {
    Write-Step 'Importing NVIDIA driver quality profile'
    $inspector = Join-Path $scriptRoot 'nvidiaProfileInspector\nvidiaProfileInspector.exe'
    $nip = Join-Path $pkgRoot 'profiles\CryOfFear-HDR-Quality.nip'
    if (Test-Path $inspector -and (Test-Path $nip)) {
        Start-Process -FilePath $inspector -ArgumentList '-silentImport', "`"$nip`"" -Verb runas -Wait
        Write-Ok "Imported CryOfFear-HDR-Quality.nip into NVIDIA driver database"
    } else {
        Write-Warn "NVIDIA Profile Inspector or profile missing - skipped."
    }
}

# --- 8. Summary & Launch Options --------------------------------------------
Write-Step 'Installation Complete!'
$launchMode = if ($Windowed) { "-window -w $Width -h $Height" } else { "-fullscreen -w $Width -h $Height" }
$steamArgs = "$launchMode -noforcemparms -noforcemaccel -noforcemspd"

Write-Host @"

Recommended Steam Launch Options:
  Right-click 'Cry of Fear' in Steam -> Properties -> Launch Options, and paste:
  $steamArgs

"@ -ForegroundColor Green
