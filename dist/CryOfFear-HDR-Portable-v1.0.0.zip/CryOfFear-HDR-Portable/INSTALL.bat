@echo off
setlocal
title Cry of Fear HDR - 1-Click Installer
cd /d "%~dp0"

echo ==============================================================================
echo   CRY OF FEAR: RTX HDR & 1440P ENHANCEMENT MOD
echo   By Collin Lerche (zfzfg) ^| STERRA (https://sterra.online)
echo ==============================================================================
echo.
echo Running automated installation...
echo If prompted by Windows User Account Control (UAC), please click YES.
echo.

powershell -ExecutionPolicy Bypass -Command "Start-Process powershell -ArgumentList '-ExecutionPolicy Bypass -NoProfile -File """%~dp0tools\Install.ps1"""' -Verb runas -Wait"

echo.
echo ==============================================================================
echo Running verification diagnostics...
echo ==============================================================================
echo.
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0tools\Test.ps1"
echo.
pause
