# Cry of Fear: RTX HDR, 1440p & Ultra-Low Latency Enhancement Mod (Portable Edition)

**Created by:** Collin Lerche (zfzfg) | STERRA ([https://sterra.online](https://sterra.online))  
**License:** MIT License (see [LICENSE](LICENSE))

---

## 🌟 Overview

This package is a **fully portable, standalone enhancement suite** for *Cry of Fear* (Steam). It upgrades the game's visuals and performance to modern high-definition standards while strictly avoiding engine crashes:

- **AI-Powered True HDR (NVIDIA RTX HDR):** Injects native HDR output via the NVIDIA display driver without needing unstable post-processing hooks.
- **Crystal Clear 2560x1440 (QHD) / 4K:** Fixes resolution scaling in the GoldSrc engine, retaining sharp visuals without blowing up UI/menu fonts.
- **Ultra-Low Latency & Instant Input:** Disables GoldSrc engine mouse smoothing (`m_filter 0`), disables V-Sync buffering lag (`gl_vsync 0`), and unlocks 101 tickrate engine updates (`cl_updaterate 101`, `cl_cmdrate 101`, `rate 100000`) for instantaneous 1:1 mouse reaction time on high refresh rate monitors (e.g. 144Hz - 300Hz G-Sync / VRR).
- **Custom Field of View (FOV):** Enhanced perspective (`cl_fovmultiplier 1.15`) for natural widescreen view distances on 16:9 and 16:10 displays.
- **Crash-Proof High Quality Driver Profile:**
  - **16x High-Quality Anisotropic Filtering** (replaces GoldSrc's blurry bilinear textures).
  - **Negative LOD Bias Clamped** with High Quality Texture Filtering.
  - **MSAA Forced OFF:** Anti-aliasing causes fatal GoldSrc engine vertex buffer crashes; keeping it disabled ensures 100% stability.
- **Softened Nightmare Post-Processing:** Replaces the jarring, eye-straining stock `black_fp.cg` nightmare shader with a balanced, atmospheric vignette.

---

## 🚀 Quick Start

You can configure and install everything with either the **modern graphical configurator** or the **1-click batch scripts**:

### Option 1: GUI Configurator (Recommended)
1. Double-click **`CryOfFearHDRConfig.exe`**.
2. Customize your preferred settings:
   - **Resolution:** 2560x1440 (Recommended), 1920x1080, 3840x2160, or Custom.
   - **Display Mode:** Fullscreen (Exclusive/Borderless) or Windowed.
   - **Field of View (FOV):** Adjust from 1.00 (Stock 90°) to 1.30 (Widescreen 110°+).
   - **Ultra-Low Latency:** Enable raw mouse input, V-Sync lag kill, and high tickrate.
   - **Visuals:** RTX HDR, 16x Anisotropic Filtering, and Softened Nightmare Shader.
3. Click **"Apply Settings & Install Mod"**.
4. In Steam, right-click *Cry of Fear* -> **Properties** -> paste the launch options:
   ```text
   -fullscreen -w 2560 -h 1440
   ```
5. Launch the game!

### Option 2: 1-Click Automated Batch Scripts
- **`INSTALL.bat`**: Automatically detects your Steam installation, installs the configuration, driver profiles, and shaders.
- **`DIAGNOSE.bat`**: Runs a comprehensive health check verifying GPU driver settings, HDR display status, and file integrity.
- **`UNINSTALL.bat`**: Restores original stock shaders and resets driver profile.

---

## 🛠️ Requirements

- **OS:** Windows 10 (Build 19041+) or Windows 11.
- **Display:** HDR-capable monitor with Windows HDR turned ON (`Win + Alt + B`).
- **GPU:** NVIDIA GeForce RTX 20-series, 30-series, 40-series, or 50-series (Driver 551.23 or newer).
- **Game:** Cry of Fear on Steam.

---

## 📁 Package Structure

```text
CryOfFear-HDR-Portable/
├── CryOfFearHDRConfig.exe            # Modern WPF Graphical Configurator
├── INSTALL.bat                       # 1-Click Automated Installer
├── UNINSTALL.bat                     # 1-Click Uninstaller & Revert Tool
├── DIAGNOSE.bat                      # Diagnostics & Status Verification
├── LICENSE                           # MIT License (Collin Lerche | STERRA)
├── README.md                         # Full documentation
├── QUICKSTART.txt                    # Concise quick-start guide
├── files/                            # Game enhancement files
│   ├── autoexec.cfg                  # Engine rates, FOV, low-latency cvars
│   └── cgshaders/black_fp.cg         # Softened nightmare Cg shader
├── profiles/                         # NVIDIA driver profile exports
│   ├── CryOfFear-HDR-Quality.nip     # RTX HDR + 16x AF + HQ Texture profile
│   └── CryOfFear-HDR-Reset.nip       # Driver reset profile
├── src/                              # Source code for the WPF Configurator
│   └── Program.cs                    # C# 5 / WPF standalone source
└── tools/                            # Scripts & profile inspector tools
    ├── Install.ps1                   # Core installer backend
    ├── Uninstall.ps1                 # Core uninstaller backend
    ├── Test.ps1                      # Diagnostic test backend
    └── nvidiaProfileInspector/       # Portable NVIDIA Profile Inspector suite
```

---

## ❓ Troubleshooting & Frequently Asked Questions

### The game starts in 1080p instead of 1440p
Make sure you set Steam launch options for Cry of Fear:
`Properties` -> `General` -> `Launch Options` -> `-fullscreen -w 2560 -h 1440`.

### The main menu font is too large or truncated
Cry of Fear's GoldSrc engine uses `cryoffear/resource/TrackerScheme.res` for menu fonts. If modified improperly, high resolutions cause text to overflow the screen. This mod maintains the stock crisp font size definitions to ensure all menus, inventory screens, and keybind dialogs render cleanly at any resolution.

### Is RTX HDR working?
Press `Alt + F3` (NVIDIA App / GeForce Overlay) or run `DIAGNOSE.bat`. You can also verify with Windows Game Bar (`Win + G`) that the display is receiving 10-bit HDR signal.

---

## 📄 License

Distributed under the MIT License. See [LICENSE](LICENSE) for details.  
Copyright (c) 2026 Collin Lerche (zfzfg) | STERRA.
Website: [https://sterra.online](https://sterra.online)
