using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Markup;
using Microsoft.Win32;

namespace CryOfFearHDRConfig
{
    public class Program : Application
    {
        [STAThread]
        public static void Main()
        {
            var app = new Program();
            app.Run(new MainWindow());
        }
    }

    public class MainWindow : Window
    {
        private TextBox txtGamePath;
        private ComboBox cmbResolution;
        private ComboBox cmbDisplayMode;
        private Slider sliderFov;
        private TextBlock lblFovValue;
        private CheckBox chkRawMouse;
        private CheckBox chkLowLatencyVsync;
        private CheckBox chkEngineRates;
        private CheckBox chkAnisotropic;
        private CheckBox chkRtxHdr;
        private CheckBox chkSoftenedShader;
        private TextBox txtLog;

        public MainWindow()
        {
            Title = "Cry of Fear: RTX HDR & 1440p Configurator";
            Width = 820;
            Height = 840;
            MinWidth = 760;
            MinHeight = 750;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = new SolidColorBrush(Color.FromRgb(18, 20, 26));
            Foreground = new SolidColorBrush(Color.FromRgb(236, 239, 244));
            FontFamily = new FontFamily("Segoe UI, Arial");

            BuildUI();
            InitializeDefaultValues();
        }

        private void BuildUI()
        {
            var grid = new Grid { Margin = new Thickness(20) };
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Header
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Scrollable Content
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Actions / Log

            // --- Header ---
            var headerBorder = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(26, 29, 38)),
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(16),
                Margin = new Thickness(0, 0, 0, 15),
                BorderBrush = new SolidColorBrush(Color.FromRgb(45, 49, 60)),
                BorderThickness = new Thickness(1)
            };

            var headerStack = new StackPanel();
            var titleRow = new StackPanel { Orientation = Orientation.Horizontal };
            var titleText = new TextBlock
            {
                Text = "CRY OF FEAR",
                FontSize = 22,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(240, 244, 250))
            };
            var badge = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(118, 185, 0)), // NVIDIA Green
                CornerRadius = new CornerRadius(4),
                Padding = new Thickness(8, 2, 8, 2),
                Margin = new Thickness(12, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            badge.Child = new TextBlock
            {
                Text = "RTX HDR & 1440p",
                FontWeight = FontWeights.Bold,
                FontSize = 12,
                Foreground = Brushes.Black
            };
            titleRow.Children.Add(titleText);
            titleRow.Children.Add(badge);
            headerStack.Children.Add(titleRow);

            var subtitle = new TextBlock
            {
                Text = "Portable High-Definition Quality & Low-Latency Enhancement | By Collin Lerche (zfzfg) - STERRA",
                FontSize = 12,
                Foreground = new SolidColorBrush(Color.FromRgb(140, 148, 165)),
                Margin = new Thickness(0, 4, 0, 0)
            };
            headerStack.Children.Add(subtitle);
            headerBorder.Child = headerStack;
            Grid.SetRow(headerBorder, 0);
            grid.Children.Add(headerBorder);

            // --- Scrollable Body ---
            var scrollViewer = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            var bodyStack = new StackPanel { Margin = new Thickness(0, 0, 10, 0) };

            // Card 1: Game Directory
            StackPanel pathPanel;
            bodyStack.Children.Add(CreateCard("1. Cry of Fear Installation Directory", out pathPanel));
            var pathRow = new Grid();
            pathRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            pathRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            txtGamePath = new TextBox
            {
                Background = new SolidColorBrush(Color.FromRgb(32, 36, 47)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(60, 66, 82)),
                Padding = new Thickness(8, 6, 8, 6),
                FontSize = 13,
                VerticalAlignment = VerticalAlignment.Center
            };
            var btnBrowse = CreateButton("Browse...", 90, 32);
            btnBrowse.Margin = new Thickness(10, 0, 0, 0);
            btnBrowse.Click += (s, e) => BrowseGameFolder();

            Grid.SetColumn(txtGamePath, 0);
            Grid.SetColumn(btnBrowse, 1);
            pathRow.Children.Add(txtGamePath);
            pathRow.Children.Add(btnBrowse);
            pathPanel.Children.Add(pathRow);

            // Card 2: Resolution & Display Mode
            StackPanel displayPanel;
            bodyStack.Children.Add(CreateCard("2. Display & Screen Resolution", out displayPanel));
            var dispGrid = new Grid();
            dispGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            dispGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var resBox = new StackPanel { Margin = new Thickness(0, 0, 10, 0) };
            resBox.Children.Add(new TextBlock { Text = "Resolution:", Foreground = Brushes.LightGray, Margin = new Thickness(0, 0, 0, 5) });
            cmbResolution = new ComboBox
            {
                Background = new SolidColorBrush(Color.FromRgb(32, 36, 47)),
                Foreground = Brushes.Black,
                Height = 30
            };
            cmbResolution.Items.Add("2560 x 1440 (Native 1440p - Recommended)");
            cmbResolution.Items.Add("1920 x 1080 (1080p FHD)");
            cmbResolution.Items.Add("3840 x 2160 (4K UHD)");
            cmbResolution.SelectedIndex = 0;
            resBox.Children.Add(cmbResolution);

            var modeBox = new StackPanel { Margin = new Thickness(10, 0, 0, 0) };
            modeBox.Children.Add(new TextBlock { Text = "Window Mode:", Foreground = Brushes.LightGray, Margin = new Thickness(0, 0, 0, 5) });
            cmbDisplayMode = new ComboBox
            {
                Background = new SolidColorBrush(Color.FromRgb(32, 36, 47)),
                Foreground = Brushes.Black,
                Height = 30
            };
            cmbDisplayMode.Items.Add("Native Fullscreen (Borderless / DirectFlip - Recommended)");
            cmbDisplayMode.Items.Add("Standard Windowed (with borders)");
            cmbDisplayMode.SelectedIndex = 0;
            modeBox.Children.Add(cmbDisplayMode);

            Grid.SetColumn(resBox, 0);
            Grid.SetColumn(modeBox, 1);
            dispGrid.Children.Add(resBox);
            dispGrid.Children.Add(modeBox);
            displayPanel.Children.Add(dispGrid);

            // Card 3: FOV Slider
            StackPanel fovPanel;
            bodyStack.Children.Add(CreateCard("3. Field of View (cl_fovmultiplier)", out fovPanel));
            var fovHeader = new Grid();
            fovHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            fovHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var fovDesc = new TextBlock
            {
                Text = "Adapts Cry of Fear's 4:3 camera for modern 16:9 widescreen monitors:",
                Foreground = Brushes.LightGray,
                VerticalAlignment = VerticalAlignment.Center
            };
            lblFovValue = new TextBlock
            {
                Text = "1.15 (~104° - Recommended Sweetspot)",
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(0, 229, 255)), // Cyan
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(fovDesc, 0);
            Grid.SetColumn(lblFovValue, 1);
            fovHeader.Children.Add(fovDesc);
            fovHeader.Children.Add(lblFovValue);
            fovPanel.Children.Add(fovHeader);

            sliderFov = new Slider
            {
                Minimum = 1.00,
                Maximum = 1.30,
                Value = 1.15,
                TickFrequency = 0.05,
                IsSnapToTickEnabled = false,
                Margin = new Thickness(0, 10, 0, 0)
            };
            sliderFov.ValueChanged += (s, e) =>
            {
                double val = Math.Round(sliderFov.Value, 2);
                int deg = (int)Math.Round(val * 90.0);
                string note = val == 1.00 ? "(Vanilla 4:3)" : val == 1.15 ? "(Recommended Sweetspot)" : val > 1.20 ? "(Very Wide)" : "(Subtle)";
                lblFovValue.Text = string.Format("{0:F2} (~{1}° {2})", val, deg, note);
            };
            fovPanel.Children.Add(sliderFov);

            // Card 4: Reaction Time & Input Latency
            StackPanel latPanel;
            bodyStack.Children.Add(CreateCard("4. Input Reaction Time & Ultra-Low Latency", out latPanel));
            chkRawMouse = new CheckBox
            {
                Content = "Direct Raw Mouse Input (m_filter 0 - disables 2-frame smoothing lag)",
                IsChecked = true,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            chkLowLatencyVsync = new CheckBox
            {
                Content = "Zero VSync Buffer Delay (gl_vsync 0 - eliminates buffer lag on VRR / 300Hz G-Sync)",
                IsChecked = true,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            chkEngineRates = new CheckBox
            {
                Content = "Synchronized Engine Tickrate (cl_cmdrate 101, cl_updaterate 101, rate 100000)",
                IsChecked = true,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            latPanel.Children.Add(chkRawMouse);
            latPanel.Children.Add(chkLowLatencyVsync);
            latPanel.Children.Add(chkEngineRates);

            // Card 5: Visual Quality & RTX HDR
            StackPanel gfxPanel;
            bodyStack.Children.Add(CreateCard("5. Visual Enhancements & Driver Quality", out gfxPanel));
            chkAnisotropic = new CheckBox
            {
                Content = "NVIDIA 16x Anisotropic Filtering & High Quality Texture Filtering (Crisp floors and corridors)",
                IsChecked = true,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            chkRtxHdr = new CheckBox
            {
                Content = "NVIDIA RTX HDR (DXGI Layered Swapchain & VeryHigh Debanding)",
                IsChecked = true,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            var chkNoMsaa = new CheckBox
            {
                Content = "Crash-Safe Engine Mode (MSAA override explicitly OFF - prevents level-transition crashes)",
                IsChecked = true,
                IsEnabled = false, // Always locked on for stability
                Foreground = new SolidColorBrush(Color.FromRgb(118, 185, 0)),
                Margin = new Thickness(0, 4, 0, 4)
            };
            chkSoftenedShader = new CheckBox
            {
                Content = "Softened Nightmare Post-Shader (black_fp.cg Cg 1.2 - prevents HDR flashbang whiteout)",
                IsChecked = false,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            gfxPanel.Children.Add(chkAnisotropic);
            gfxPanel.Children.Add(chkRtxHdr);
            gfxPanel.Children.Add(chkNoMsaa);
            gfxPanel.Children.Add(chkSoftenedShader);

            scrollViewer.Content = bodyStack;
            Grid.SetRow(scrollViewer, 1);
            grid.Children.Add(scrollViewer);

            // --- Footer Area (Action Buttons & Log) ---
            var footerStack = new StackPanel { Margin = new Thickness(0, 15, 0, 0) };

            var btnRow = new WrapPanel { Margin = new Thickness(0, 0, 0, 10) };
            var btnInstall = CreatePrimaryButton("✓ Apply & Install Everything", 230, 40);
            btnInstall.Click += (s, e) => ApplyAndInstall();

            var btnCopyLaunch = CreateButton("📋 Copy Steam Launch Options", 210, 40);
            btnCopyLaunch.Click += (s, e) => CopyLaunchOptions();

            var btnTest = CreateButton("🔍 Run Diagnostics", 150, 40);
            btnTest.Click += (s, e) => RunDiagnostics();

            var btnRevert = CreateDangerButton("↺ Revert to Stock", 150, 40);
            btnRevert.Click += (s, e) => RevertStock();

            btnRow.Children.Add(btnInstall);
            btnRow.Children.Add(btnCopyLaunch);
            btnRow.Children.Add(btnTest);
            btnRow.Children.Add(btnRevert);
            footerStack.Children.Add(btnRow);

            txtLog = new TextBox
            {
                Background = new SolidColorBrush(Color.FromRgb(14, 16, 22)),
                Foreground = new SolidColorBrush(Color.FromRgb(180, 240, 180)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(40, 45, 55)),
                Height = 110,
                IsReadOnly = true,
                TextWrapping = TextWrapping.Wrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                FontFamily = new FontFamily("Consolas, Courier New"),
                FontSize = 12,
                Padding = new Thickness(8)
            };
            footerStack.Children.Add(txtLog);

            Grid.SetRow(footerStack, 2);
            grid.Children.Add(footerStack);

            Content = grid;
        }

        private Border CreateCard(string title, out StackPanel contentPanel)
        {
            var border = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(24, 27, 35)),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(14),
                Margin = new Thickness(0, 0, 0, 12),
                BorderBrush = new SolidColorBrush(Color.FromRgb(38, 43, 54)),
                BorderThickness = new Thickness(1)
            };
            var stack = new StackPanel();
            var header = new TextBlock
            {
                Text = title,
                FontSize = 14,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(220, 225, 235)),
                Margin = new Thickness(0, 0, 0, 10)
            };
            stack.Children.Add(header);
            contentPanel = new StackPanel();
            stack.Children.Add(contentPanel);
            border.Child = stack;
            return border;
        }

        private Button CreatePrimaryButton(string text, double width, double height)
        {
            var btn = new Button
            {
                Content = text,
                Width = width,
                Height = height,
                Background = new SolidColorBrush(Color.FromRgb(0, 180, 80)),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                FontSize = 13,
                Margin = new Thickness(0, 0, 10, 0),
                Cursor = System.Windows.Input.Cursors.Hand
            };
            return btn;
        }

        private Button CreateButton(string text, double width, double height)
        {
            var btn = new Button
            {
                Content = text,
                Width = width,
                Height = height,
                Background = new SolidColorBrush(Color.FromRgb(36, 41, 52)),
                Foreground = Brushes.White,
                FontSize = 12,
                Margin = new Thickness(0, 0, 10, 0),
                BorderBrush = new SolidColorBrush(Color.FromRgb(55, 62, 78)),
                Cursor = System.Windows.Input.Cursors.Hand
            };
            return btn;
        }

        private Button CreateDangerButton(string text, double width, double height)
        {
            var btn = new Button
            {
                Content = text,
                Width = width,
                Height = height,
                Background = new SolidColorBrush(Color.FromRgb(70, 30, 35)),
                Foreground = new SolidColorBrush(Color.FromRgb(255, 120, 120)),
                FontSize = 12,
                Margin = new Thickness(0, 0, 0, 0),
                BorderBrush = new SolidColorBrush(Color.FromRgb(120, 50, 55)),
                Cursor = System.Windows.Input.Cursors.Hand
            };
            return btn;
        }

        private void Log(string msg)
        {
            txtLog.AppendText(string.Format("[{0:HH:mm:ss}] {1}\n", DateTime.Now, msg));
            txtLog.ScrollToEnd();
        }

        private void InitializeDefaultValues()
        {
            string detected = FindCryOfFear();
            if (!string.IsNullOrEmpty(detected))
            {
                txtGamePath.Text = detected;
                Log("Auto-detected Cry of Fear at: " + detected);
            }
            else
            {
                Log("Cry of Fear path not found automatically. Please select it manually.");
            }
        }

        private string FindCryOfFear()
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam"))
                {
                    if (key == null) return null;
                    string steamPath = key.GetValue("SteamPath") as string;
                    if (string.IsNullOrEmpty(steamPath)) return null;

                    string defaultCandidate = Path.Combine(steamPath, @"steamapps\common\Cry of Fear");
                    if (File.Exists(Path.Combine(defaultCandidate, "cof.exe"))) return defaultCandidate;

                    string vdf = Path.Combine(steamPath, @"steamapps\libraryfolders.vdf");
                    if (File.Exists(vdf))
                    {
                        string content = File.ReadAllText(vdf);
                        var matches = Regex.Matches(content, @"""path""\s+""([^""]+)""");
                        foreach (Match m in matches)
                        {
                            string lib = m.Groups[1].Value.Replace(@"\\", @"\");
                            string candidate = Path.Combine(lib, @"steamapps\common\Cry of Fear");
                            if (File.Exists(Path.Combine(candidate, "cof.exe"))) return candidate;
                        }
                    }
                }
            }
            catch { }
            return null;
        }

        private void BrowseGameFolder()
        {
            var dlg = new OpenFileDialog
            {
                Title = "Select Cry of Fear Executable (cof.exe)",
                Filter = "Cry of Fear Executable (cof.exe)|cof.exe|All Executables (*.exe)|*.exe",
                FileName = "cof.exe"
            };
            if (dlg.ShowDialog() == true)
            {
                txtGamePath.Text = Path.GetDirectoryName(dlg.FileName);
                Log("Selected game folder: " + txtGamePath.Text);
            }
        }

        private void ApplyAndInstall()
        {
            string gameDir = txtGamePath.Text.Trim();
            if (string.IsNullOrEmpty(gameDir) || !File.Exists(Path.Combine(gameDir, "cof.exe")))
            {
                MessageBox.Show("Please select a valid Cry of Fear directory containing 'cof.exe'.", "Invalid Path", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                Log("Starting deployment...");

                int width = cmbResolution.SelectedIndex == 1 ? 1920 : cmbResolution.SelectedIndex == 2 ? 3840 : 2560;
                int height = cmbResolution.SelectedIndex == 1 ? 1080 : cmbResolution.SelectedIndex == 2 ? 2160 : 1440;
                bool windowed = cmbDisplayMode.SelectedIndex == 1;
                double fov = Math.Round(sliderFov.Value, 2);

                // 1. Back up original files
                string modDir = Path.Combine(gameDir, "cryoffear");
                string appDir = AppDomain.CurrentDomain.BaseDirectory;
                string backupDir = Path.Combine(appDir, @"backup\original");
                if (!Directory.Exists(backupDir))
                {
                    Directory.CreateDirectory(backupDir);
                    foreach (string item in new[] { "autoexec.cfg", "config.cfg", "scriptsettings.dat" })
                    {
                        string src = Path.Combine(modDir, item);
                        if (File.Exists(src)) File.Copy(src, Path.Combine(backupDir, item), true);
                    }
                    Log("Created pristine backup at: backup\\original");
                }

                // 2. Generate and write autoexec.cfg
                var sb = new StringBuilder();
                sb.AppendLine("// Cry of Fear HDR & 1440p Enhanced autoexec.cfg");
                sb.AppendLine("// Configured by CryOfFearHDRConfig (Collin Lerche | STERRA)");
                sb.AppendLine("sv_maxspeed 300\nsv_cheats 0\nr_dynamiclight 0\ncl_noiseeffect 1\ncl_sidespeed 200\ncl_backspeed 200\ngl_max_size 1024\nsv_voicecodec voice_speex\nsv_voicequality 5\nsv_lan 0");
                sb.AppendLine("gl_renderer 1");
                sb.AppendLine("gl_twopassdyn 1");
                sb.AppendLine("brightness 1\ngamma 2.5\ngl_brightness 0\ngl_gamma 1\ngl_posteffects 1\ngl_texturemode gl_linear_mipmap_linear");
                sb.AppendLine(string.Format("cl_fovmultiplier {0:F2}", fov));

                if (chkRawMouse.IsChecked == true) sb.AppendLine("m_filter 0");
                if (chkLowLatencyVsync.IsChecked == true) sb.AppendLine("gl_vsync 0");
                if (chkEngineRates.IsChecked == true) sb.AppendLine("cl_cmdrate 101\ncl_updaterate 101\nrate 100000");
                sb.AppendLine("fps_max 100\ndeveloper 0");

                File.WriteAllText(Path.Combine(modDir, "autoexec.cfg"), sb.ToString(), Encoding.ASCII);
                Log(string.Format("autoexec.cfg deployed (FOV: {0:F2}, 100 FPS, Low-Latency)", fov));

                // 3. Set High-DPI override
                string layersKey = @"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers";
                using (var key = Registry.CurrentUser.CreateSubKey(layersKey))
                {
                    string cofExe = Path.Combine(gameDir, "cof.exe");
                    string existing = (key.GetValue(cofExe) as string) ?? "";
                    if (!existing.Contains("HIGHDPIAWARE"))
                    {
                        key.SetValue(cofExe, (existing + " HIGHDPIAWARE").TrimStart());
                    }
                }
                Log("High-DPI application override enabled.");

                // 4. Registry Resolution
                string settingsKey = @"Software\Valve\Cry of Fear\Settings";
                using (var key = Registry.CurrentUser.CreateSubKey(settingsKey))
                {
                    key.SetValue("ScreenWidth", width, RegistryValueKind.DWord);
                    key.SetValue("ScreenHeight", height, RegistryValueKind.DWord);
                    key.SetValue("SCREENWINDOWED", windowed ? 1 : 0, RegistryValueKind.DWord);
                }
                Log(string.Format("Registry set to {0}x{1} ({2})", width, height, windowed ? "Windowed" : "Fullscreen"));

                // 5. Optional Shader
                if (chkSoftenedShader.IsChecked == true)
                {
                    string srcShader = Path.Combine(appDir, @"files\cgshaders\black_fp.cg");
                    string dstShader = Path.Combine(modDir, @"cgshaders\black_fp.cg");
                    if (File.Exists(srcShader))
                    {
                        File.Copy(srcShader, dstShader, true);
                        Log("Softened nightmare shader (black_fp.cg) installed.");
                    }
                }

                // 6. Driver Profile Import
                if (chkRtxHdr.IsChecked == true || chkAnisotropic.IsChecked == true)
                {
                    string inspector = Path.Combine(appDir, @"tools\nvidiaProfileInspector\nvidiaProfileInspector.exe");
                    string nip = Path.Combine(appDir, @"profiles\CryOfFear-HDR-Quality.nip");
                    if (File.Exists(inspector) && File.Exists(nip))
                    {
                        Log("Invoking NVIDIA Profile Inspector with administrator elevation...");
                        var psi = new ProcessStartInfo
                        {
                            FileName = inspector,
                            Arguments = string.Format("-silentImport \"{0}\"", nip),
                            Verb = "runas",
                            UseShellExecute = true
                        };
                        var proc = Process.Start(psi);
                        proc.WaitForExit();
                        Log("NVIDIA Driver Profile (RTX HDR + 16x AF) imported successfully.");
                    }
                }

                Log("✓ ALL SETTINGS APPLIED SUCCESSFULLY!");
                MessageBox.Show("All settings, files, and driver profiles have been applied successfully!\n\nRemember to paste the recommended launch options into Steam properties.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                Log("ERROR: " + ex.Message);
                MessageBox.Show("Error applying settings: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CopyLaunchOptions()
        {
            int width = cmbResolution.SelectedIndex == 1 ? 1920 : cmbResolution.SelectedIndex == 2 ? 3840 : 2560;
            int height = cmbResolution.SelectedIndex == 1 ? 1080 : cmbResolution.SelectedIndex == 2 ? 2160 : 1440;
            bool windowed = cmbDisplayMode.SelectedIndex == 1;

            string modeFlag = windowed ? string.Format("-window -w {0} -h {1}", width, height) : string.Format("-fullscreen -w {0} -h {1}", width, height);
            string args = string.Format("{0} -noforcemparms -noforcemaccel -noforcemspd", modeFlag);

            Clipboard.SetText(args);
            Log("Copied to clipboard: " + args);
            MessageBox.Show("Copied to clipboard:\n\n" + args + "\n\nPaste this in Steam -> Cry of Fear -> Properties -> Launch Options.", "Copied", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void RunDiagnostics()
        {
            Log("Running diagnostics...");
            string appDir = AppDomain.CurrentDomain.BaseDirectory;
            string testScript = Path.Combine(appDir, @"tools\Test.ps1");
            if (!File.Exists(testScript))
            {
                Log("Test.ps1 not found.");
                return;
            }

            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = string.Format("-ExecutionPolicy Bypass -NoProfile -File \"{0}\" -GamePath \"{1}\"", testScript, txtGamePath.Text),
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                var proc = Process.Start(psi);
                string output = proc.StandardOutput.ReadToEnd();
                proc.WaitForExit();
                Log("\n" + output);
            }
            catch (Exception ex)
            {
                Log("Diagnostic error: " + ex.Message);
            }
        }

        private void RevertStock()
        {
            if (MessageBox.Show("Are you sure you want to revert all changes back to stock?", "Confirm Revert", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                Log("Reverting files and driver profile...");
                string appDir = AppDomain.CurrentDomain.BaseDirectory;
                string uninstScript = Path.Combine(appDir, @"tools\Uninstall.ps1");
                if (File.Exists(uninstScript))
                {
                    var psi = new ProcessStartInfo
                    {
                        FileName = "powershell.exe",
                        Arguments = string.Format("-ExecutionPolicy Bypass -NoProfile -File \"{0}\" -GamePath \"{1}\"", uninstScript, txtGamePath.Text),
                        Verb = "runas",
                        UseShellExecute = true
                    };
                    var proc = Process.Start(psi);
                    proc.WaitForExit();
                    Log("Restored original files and reset driver profile.");
                    MessageBox.Show("Cry of Fear restored back to stock vanilla.", "Reverted", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                Log("Revert error: " + ex.Message);
            }
        }
    }
}
