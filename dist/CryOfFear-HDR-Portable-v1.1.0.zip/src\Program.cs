using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;

namespace CryOfFearHDRConfig
{
    public class Program : Application
    {
        [STAThread]
        public static void Main()
        {
            var app = new Program();
            app.Run(new MainWindow());
        }
    }

    public class MainWindow : Window
    {
        private TextBox txtGamePath;
        private ComboBox cmbResolution;
        private ComboBox cmbDisplayMode;
        private TextBox txtWidth;
        private TextBox txtHeight;
        private Slider sliderFov;
        private TextBlock lblFovValue;
        private CheckBox chkRawMouse;
        private CheckBox chkLowLatencyVsync;
        private CheckBox chkEngineRates;
        private CheckBox chkRtxHdr;
        private CheckBox chkSoftenedShader;
        private TextBox txtLog;

        public MainWindow()
        {
            Title = "Cry of Fear: RTX HDR & 1440p Configurator";
            Width = 820;
            Height = 880;
            MinWidth = 760;
            MinHeight = 750;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = new SolidColorBrush(Color.FromRgb(18, 20, 26));
            Foreground = new SolidColorBrush(Color.FromRgb(236, 239, 244));
            FontFamily = new FontFamily("Segoe UI, Arial");

            BuildUI();
            InitializeDefaultValues();
        }

        private void BuildUI()
        {
            var grid = new Grid { Margin = new Thickness(20) };
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var headerBorder = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(26, 29, 38)),
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(16),
                Margin = new Thickness(0, 0, 0, 15),
                BorderBrush = new SolidColorBrush(Color.FromRgb(45, 49, 60)),
                BorderThickness = new Thickness(1)
            };

            var headerStack = new StackPanel();
            var titleRow = new StackPanel { Orientation = Orientation.Horizontal };
            var titleText = new TextBlock
            {
                Text = "CRY OF FEAR",
                FontSize = 22,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(240, 244, 250))
            };
            var badge = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(118, 185, 0)),
                CornerRadius = new CornerRadius(4),
                Padding = new Thickness(8, 2, 8, 2),
                Margin = new Thickness(12, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            badge.Child = new TextBlock
            {
                Text = "RTX HDR & 1440p",
                FontWeight = FontWeights.Bold,
                FontSize = 12,
                Foreground = Brushes.Black
            };
            titleRow.Children.Add(titleText);
            titleRow.Children.Add(badge);
            headerStack.Children.Add(titleRow);

            var subtitle = new TextBlock
            {
                Text = "Portable High-Definition Quality & Low-Latency Enhancement | By Collin Lerche (zfzfg) - STERRA",
                FontSize = 12,
                Foreground = new SolidColorBrush(Color.FromRgb(140, 148, 165)),
                Margin = new Thickness(0, 4, 0, 0)
            };
            headerStack.Children.Add(subtitle);
            headerBorder.Child = headerStack;
            Grid.SetRow(headerBorder, 0);
            grid.Children.Add(headerBorder);

            var scrollViewer = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            var bodyStack = new StackPanel { Margin = new Thickness(0, 0, 10, 0) };

            StackPanel pathPanel;
            bodyStack.Children.Add(CreateCard("1. Cry of Fear Installation Directory", out pathPanel));
            var pathRow = new Grid();
            pathRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            pathRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            txtGamePath = new TextBox
            {
                Background = new SolidColorBrush(Color.FromRgb(32, 36, 47)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(60, 66, 82)),
                Padding = new Thickness(8, 6, 8, 6),
                FontSize = 13,
                VerticalAlignment = VerticalAlignment.Center
            };
            var btnBrowse = CreateButton("Browse...", 90, 32);
            btnBrowse.Margin = new Thickness(10, 0, 0, 0);
            btnBrowse.Click += (s, e) => BrowseGameFolder();

            Grid.SetColumn(txtGamePath, 0);
            Grid.SetColumn(btnBrowse, 1);
            pathRow.Children.Add(txtGamePath);
            pathRow.Children.Add(btnBrowse);
            pathPanel.Children.Add(pathRow);

            StackPanel displayPanel;
            bodyStack.Children.Add(CreateCard("2. Display & Screen Resolution", out displayPanel));
            var dispGrid = new Grid();
            dispGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            dispGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var resBox = new StackPanel { Margin = new Thickness(0, 0, 10, 0) };
            resBox.Children.Add(new TextBlock { Text = "Resolution:", Foreground = Brushes.LightGray, Margin = new Thickness(0, 0, 0, 5) });
            cmbResolution = new ComboBox
            {
                Background = new SolidColorBrush(Color.FromRgb(32, 36, 47)),
                Foreground = Brushes.Black,
                Height = 30
            };
            cmbResolution.Items.Add("2560 x 1440 (Native 1440p - Recommended)");
            cmbResolution.Items.Add("1920 x 1080 (1080p FHD)");
            cmbResolution.Items.Add("3840 x 2160 (4K UHD)");
            cmbResolution.Items.Add("Desktop native");
            cmbResolution.Items.Add("Custom");
            cmbResolution.SelectedIndex = 0;
            cmbResolution.SelectionChanged += (s, e) => ApplyResolutionPreset();
            resBox.Children.Add(cmbResolution);

            var customRow = new Grid { Margin = new Thickness(0, 8, 0, 0) };
            customRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            customRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            customRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            txtWidth = new TextBox
            {
                Background = new SolidColorBrush(Color.FromRgb(32, 36, 47)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(60, 66, 82)),
                Padding = new Thickness(8, 4, 8, 4),
                Text = "2560"
            };
            txtHeight = new TextBox
            {
                Background = new SolidColorBrush(Color.FromRgb(32, 36, 47)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(60, 66, 82)),
                Padding = new Thickness(8, 4, 8, 4),
                Text = "1440"
            };
            var xLabel = new TextBlock
            {
                Text = " x ",
                Foreground = Brushes.LightGray,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(6, 0, 6, 0)
            };
            Grid.SetColumn(txtWidth, 0);
            Grid.SetColumn(xLabel, 1);
            Grid.SetColumn(txtHeight, 2);
            customRow.Children.Add(txtWidth);
            customRow.Children.Add(xLabel);
            customRow.Children.Add(txtHeight);
            resBox.Children.Add(customRow);

            var modeBox = new StackPanel { Margin = new Thickness(10, 0, 0, 0) };
            modeBox.Children.Add(new TextBlock { Text = "Window Mode:", Foreground = Brushes.LightGray, Margin = new Thickness(0, 0, 0, 5) });
            cmbDisplayMode = new ComboBox
            {
                Background = new SolidColorBrush(Color.FromRgb(32, 36, 47)),
                Foreground = Brushes.Black,
                Height = 30
            };
            cmbDisplayMode.Items.Add("Fullscreen (Recommended)");
            cmbDisplayMode.Items.Add("Windowed (with borders)");
            cmbDisplayMode.SelectedIndex = 0;
            modeBox.Children.Add(cmbDisplayMode);

            Grid.SetColumn(resBox, 0);
            Grid.SetColumn(modeBox, 1);
            dispGrid.Children.Add(resBox);
            dispGrid.Children.Add(modeBox);
            displayPanel.Children.Add(dispGrid);

            StackPanel fovPanel;
            bodyStack.Children.Add(CreateCard("3. Field of View (cl_fovmultiplier)", out fovPanel));
            var fovHeader = new Grid();
            fovHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            fovHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var fovDesc = new TextBlock
            {
                Text = "Adapts Cry of Fear's 4:3 camera for modern 16:9 widescreen monitors:",
                Foreground = Brushes.LightGray,
                VerticalAlignment = VerticalAlignment.Center
            };
            lblFovValue = new TextBlock
            {
                Text = "1.15 (~104° - Recommended Sweetspot)",
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(0, 229, 255)),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(fovDesc, 0);
            Grid.SetColumn(lblFovValue, 1);
            fovHeader.Children.Add(fovDesc);
            fovHeader.Children.Add(lblFovValue);
            fovPanel.Children.Add(fovHeader);

            sliderFov = new Slider
            {
                Minimum = 1.00,
                Maximum = 1.30,
                Value = 1.15,
                TickFrequency = 0.05,
                IsSnapToTickEnabled = false,
                Margin = new Thickness(0, 10, 0, 0)
            };
            sliderFov.ValueChanged += (s, e) =>
            {
                double val = Math.Round(sliderFov.Value, 2);
                int deg = (int)Math.Round(val * 90.0);
                string note = val == 1.00 ? "(Vanilla 4:3)" : val == 1.15 ? "(Recommended Sweetspot)" : val > 1.20 ? "(Very Wide)" : "(Subtle)";
                lblFovValue.Text = string.Format("{0:F2} (~{1}° {2})", val, deg, note);
            };
            fovPanel.Children.Add(sliderFov);

            StackPanel latPanel;
            bodyStack.Children.Add(CreateCard("4. Input Reaction Time & Ultra-Low Latency", out latPanel));
            chkRawMouse = new CheckBox
            {
                Content = "Direct Raw Mouse Input (m_filter 0 - disables 2-frame smoothing lag)",
                IsChecked = true,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            chkLowLatencyVsync = new CheckBox
            {
                Content = "Zero VSync Buffer Delay (gl_vsync 0 - eliminates buffer lag on VRR / 300Hz G-Sync)",
                IsChecked = true,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            chkEngineRates = new CheckBox
            {
                Content = "Synchronized Engine Tickrate (cl_cmdrate 101, cl_updaterate 101, rate 100000)",
                IsChecked = true,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            latPanel.Children.Add(chkRawMouse);
            latPanel.Children.Add(chkLowLatencyVsync);
            latPanel.Children.Add(chkEngineRates);

            StackPanel gfxPanel;
            bodyStack.Children.Add(CreateCard("5. Visual Enhancements & Driver Quality", out gfxPanel));
            chkRtxHdr = new CheckBox
            {
                Content = "NVIDIA RTX HDR Route 3B + 16x AF (DXGI layered swapchain, VeryHigh debanding, MSAA off)",
                IsChecked = true,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            var chkNoMsaa = new CheckBox
            {
                Content = "Crash-Safe Engine Mode (MSAA override explicitly OFF - prevents level-transition crashes)",
                IsChecked = true,
                IsEnabled = false,
                Foreground = new SolidColorBrush(Color.FromRgb(118, 185, 0)),
                Margin = new Thickness(0, 4, 0, 4)
            };
            chkSoftenedShader = new CheckBox
            {
                Content = "Softened Nightmare Post-Shader (black_fp.cg Cg 1.2 - prevents HDR flashbang whiteout)",
                IsChecked = false,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 4, 0, 4)
            };
            gfxPanel.Children.Add(chkRtxHdr);
            gfxPanel.Children.Add(chkNoMsaa);
            gfxPanel.Children.Add(chkSoftenedShader);
            gfxPanel.Children.Add(new TextBlock
            {
                Text = "Install also checks Windows HDR and turns Auto HDR off for cof.exe only.",
                Foreground = new SolidColorBrush(Color.FromRgb(140, 148, 165)),
                FontSize = 12,
                Margin = new Thickness(0, 6, 0, 0),
                TextWrapping = TextWrapping.Wrap
            });

            scrollViewer.Content = bodyStack;
            Grid.SetRow(scrollViewer, 1);
            grid.Children.Add(scrollViewer);

            var footerStack = new StackPanel { Margin = new Thickness(0, 15, 0, 0) };

            var btnRow = new WrapPanel { Margin = new Thickness(0, 0, 0, 10) };
            var btnInstall = CreatePrimaryButton("✓ Apply & Install Everything", 230, 40);
            btnInstall.Click += (s, e) => ApplyAndInstall();

            var btnCopyLaunch = CreateButton("📋 Copy Steam Launch Options", 210, 40);
            btnCopyLaunch.Click += (s, e) => CopyLaunchOptions();

            var btnTest = CreateButton("🔍 Run Diagnostics", 150, 40);
            btnTest.Click += (s, e) => RunDiagnostics();

            var btnRevert = CreateDangerButton("↺ Revert to Stock", 150, 40);
            btnRevert.Click += (s, e) => RevertStock();

            btnRow.Children.Add(btnInstall);
            btnRow.Children.Add(btnCopyLaunch);
            btnRow.Children.Add(btnTest);
            btnRow.Children.Add(btnRevert);
            footerStack.Children.Add(btnRow);

            txtLog = new TextBox
            {
                Background = new SolidColorBrush(Color.FromRgb(14, 16, 22)),
                Foreground = new SolidColorBrush(Color.FromRgb(180, 240, 180)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(40, 45, 55)),
                Height = 110,
                IsReadOnly = true,
                TextWrapping = TextWrapping.Wrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                FontFamily = new FontFamily("Consolas, Courier New"),
                FontSize = 12,
                Padding = new Thickness(8)
            };
            footerStack.Children.Add(txtLog);

            Grid.SetRow(footerStack, 2);
            grid.Children.Add(footerStack);

            Content = grid;
        }

        private Border CreateCard(string title, out StackPanel contentPanel)
        {
            var border = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(24, 27, 35)),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(14),
                Margin = new Thickness(0, 0, 0, 12),
                BorderBrush = new SolidColorBrush(Color.FromRgb(38, 43, 54)),
                BorderThickness = new Thickness(1)
            };
            var stack = new StackPanel();
            var header = new TextBlock
            {
                Text = title,
                FontSize = 14,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(220, 225, 235)),
                Margin = new Thickness(0, 0, 0, 10)
            };
            stack.Children.Add(header);
            contentPanel = new StackPanel();
            stack.Children.Add(contentPanel);
            border.Child = stack;
            return border;
        }

        private Button CreatePrimaryButton(string text, double width, double height)
        {
            return new Button
            {
                Content = text,
                Width = width,
                Height = height,
                Background = new SolidColorBrush(Color.FromRgb(0, 180, 80)),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                FontSize = 13,
                Margin = new Thickness(0, 0, 10, 0),
                Cursor = System.Windows.Input.Cursors.Hand
            };
        }

        private Button CreateButton(string text, double width, double height)
        {
            return new Button
            {
                Content = text,
                Width = width,
                Height = height,
                Background = new SolidColorBrush(Color.FromRgb(36, 41, 52)),
                Foreground = Brushes.White,
                FontSize = 12,
                Margin = new Thickness(0, 0, 10, 0),
                BorderBrush = new SolidColorBrush(Color.FromRgb(55, 62, 78)),
                Cursor = System.Windows.Input.Cursors.Hand
            };
        }

        private Button CreateDangerButton(string text, double width, double height)
        {
            return new Button
            {
                Content = text,
                Width = width,
                Height = height,
                Background = new SolidColorBrush(Color.FromRgb(70, 30, 35)),
                Foreground = new SolidColorBrush(Color.FromRgb(255, 120, 120)),
                FontSize = 12,
                Margin = new Thickness(0, 0, 0, 0),
                BorderBrush = new SolidColorBrush(Color.FromRgb(120, 50, 55)),
                Cursor = System.Windows.Input.Cursors.Hand
            };
        }

        private void Log(string msg)
        {
            txtLog.AppendText(string.Format("[{0:HH:mm:ss}] {1}\n", DateTime.Now, msg));
            txtLog.ScrollToEnd();
        }

        private void InitializeDefaultValues()
        {
            string detected = FindCryOfFear();
            if (!string.IsNullOrEmpty(detected))
            {
                txtGamePath.Text = detected;
                Log("Auto-detected Cry of Fear at: " + detected);
            }
            else
            {
                Log("Cry of Fear path not found automatically. Please select it manually.");
            }
            ApplyResolutionPreset();
        }

        private void ApplyResolutionPreset()
        {
            if (cmbResolution == null || txtWidth == null || txtHeight == null) return;
            switch (cmbResolution.SelectedIndex)
            {
                case 1:
                    txtWidth.Text = "1920";
                    txtHeight.Text = "1080";
                    break;
                case 2:
                    txtWidth.Text = "3840";
                    txtHeight.Text = "2160";
                    break;
                case 3:
                    txtWidth.Text = "0";
                    txtHeight.Text = "0";
                    break;
                case 4:
                    break;
                default:
                    txtWidth.Text = "2560";
                    txtHeight.Text = "1440";
                    break;
            }
        }

        private bool TryGetResolution(out int width, out int height)
        {
            width = 2560;
            height = 1440;
            if (cmbResolution.SelectedIndex == 3)
            {
                width = 0;
                height = 0;
                return true;
            }
            if (!int.TryParse(txtWidth.Text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out width) ||
                !int.TryParse(txtHeight.Text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out height) ||
                width < 640 || height < 480)
            {
                MessageBox.Show("Please enter a valid custom resolution (at least 640x480), or pick Desktop native.", "Invalid Resolution", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            return true;
        }

        private string BuildLaunchOptions()
        {
            int width, height;
            if (!TryGetResolution(out width, out height)) return null;
            if (width <= 0) width = 2560;
            if (height <= 0) height = 1440;
            bool windowed = cmbDisplayMode.SelectedIndex == 1;
            string modeFlag = windowed
                ? string.Format("-window -w {0} -h {1}", width, height)
                : string.Format("-fullscreen -w {0} -h {1}", width, height);
            return modeFlag + " -noforcemparms -noforcemaccel -noforcemspd";
        }

        private string FindCryOfFear()
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam"))
                {
                    if (key == null) return null;
                    string steamPath = key.GetValue("SteamPath") as string;
                    if (string.IsNullOrEmpty(steamPath)) return null;

                    string defaultCandidate = Path.Combine(steamPath, @"steamapps\common\Cry of Fear");
                    if (File.Exists(Path.Combine(defaultCandidate, "cof.exe"))) return defaultCandidate;

                    string vdf = Path.Combine(steamPath, @"steamapps\libraryfolders.vdf");
                    if (File.Exists(vdf))
                    {
                        string content = File.ReadAllText(vdf);
                        var matches = Regex.Matches(content, @"""path""\s+""([^""]+)""");
                        foreach (Match m in matches)
                        {
                            string lib = m.Groups[1].Value.Replace(@"\\", @"\");
                            string candidate = Path.Combine(lib, @"steamapps\common\Cry of Fear");
                            if (File.Exists(Path.Combine(candidate, "cof.exe"))) return candidate;
                        }
                    }
                }
            }
            catch { }
            return null;
        }

        private void BrowseGameFolder()
        {
            var dlg = new OpenFileDialog
            {
                Title = "Select Cry of Fear Executable (cof.exe)",
                Filter = "Cry of Fear Executable (cof.exe)|cof.exe|All Executables (*.exe)|*.exe",
                FileName = "cof.exe"
            };
            if (dlg.ShowDialog() == true)
            {
                txtGamePath.Text = Path.GetDirectoryName(dlg.FileName);
                Log("Selected game folder: " + txtGamePath.Text);
            }
        }

        private string Quote(string value)
        {
            return "\"" + value.Replace("\"", "\\\"") + "\"";
        }

        private bool RunScript(string scriptName, string extraArgs, bool captureOutput)
        {
            string appDir = AppDomain.CurrentDomain.BaseDirectory;
            string script = Path.Combine(appDir, @"tools\" + scriptName);
            if (!File.Exists(script))
            {
                Log(scriptName + " not found.");
                return false;
            }

            var args = new StringBuilder();
            args.Append("-ExecutionPolicy Bypass -NoProfile -File ");
            args.Append(Quote(script));
            if (!string.IsNullOrEmpty(extraArgs))
            {
                args.Append(' ');
                args.Append(extraArgs);
            }

            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = args.ToString(),
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = captureOutput,
                    RedirectStandardError = captureOutput
                };
                var proc = Process.Start(psi);
                if (proc == null)
                {
                    Log("Failed to start PowerShell.");
                    return false;
                }
                if (captureOutput)
                {
                    string output = proc.StandardOutput.ReadToEnd();
                    string err = proc.StandardError.ReadToEnd();
                    proc.WaitForExit();
                    if (!string.IsNullOrWhiteSpace(output)) Log("\n" + output.TrimEnd());
                    if (!string.IsNullOrWhiteSpace(err)) Log(err.TrimEnd());
                }
                else
                {
                    proc.WaitForExit();
                }
                return proc.ExitCode == 0;
            }
            catch (Exception ex)
            {
                Log("ERROR: " + ex.Message);
                return false;
            }
        }

        private void ApplyAndInstall()
        {
            string gameDir = txtGamePath.Text.Trim();
            if (string.IsNullOrEmpty(gameDir) || !File.Exists(Path.Combine(gameDir, "cof.exe")))
            {
                MessageBox.Show("Please select a valid Cry of Fear directory containing 'cof.exe'.", "Invalid Path", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int width, height;
            if (!TryGetResolution(out width, out height)) return;

            double fov = Math.Round(sliderFov.Value, 2);
            bool windowed = cmbDisplayMode.SelectedIndex == 1;

            var extra = new StringBuilder();
            extra.Append("-GamePath ").Append(Quote(gameDir));
            extra.Append(" -Fov ").Append(fov.ToString("F2", CultureInfo.InvariantCulture));
            extra.Append(" -Width ").Append(width);
            extra.Append(" -Height ").Append(height);
            extra.Append(" -RawMouse:$").Append(chkRawMouse.IsChecked == true ? "true" : "false");
            extra.Append(" -LowLatencyVsync:$").Append(chkLowLatencyVsync.IsChecked == true ? "true" : "false");
            extra.Append(" -EngineRates:$").Append(chkEngineRates.IsChecked == true ? "true" : "false");
            if (windowed) extra.Append(" -Windowed");
            if (chkSoftenedShader.IsChecked == true) extra.Append(" -Shader");
            if (chkRtxHdr.IsChecked != true) extra.Append(" -SkipProfile");

            Log("Starting deployment via Install.ps1...");
            bool ok = RunScript("Install.ps1", extra.ToString(), true);
            if (ok)
            {
                string launch = BuildLaunchOptions();
                if (!string.IsNullOrEmpty(launch))
                {
                    try { Clipboard.SetText(launch); }
                    catch { }
                    Log("Copied Steam launch options: " + launch);
                }
                Log("✓ ALL SETTINGS APPLIED SUCCESSFULLY!");
                MessageBox.Show(
                    "Settings applied.\n\nAuto HDR is off for cof.exe only.\nWindows HDR was checked (turn it on in Settings if diagnostics warn).\n\nLaunch options were copied to the clipboard — paste them in Steam → Cry of Fear → Properties.",
                    "Success",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Install finished with errors. See the log.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CopyLaunchOptions()
        {
            string args = BuildLaunchOptions();
            if (string.IsNullOrEmpty(args)) return;
            Clipboard.SetText(args);
            Log("Copied to clipboard: " + args);
            MessageBox.Show("Copied to clipboard:\n\n" + args + "\n\nPaste this in Steam -> Cry of Fear -> Properties -> Launch Options.", "Copied", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void RunDiagnostics()
        {
            Log("Running diagnostics...");
            string extra = "";
            if (!string.IsNullOrWhiteSpace(txtGamePath.Text))
                extra = "-GamePath " + Quote(txtGamePath.Text.Trim());
            RunScript("Test.ps1", extra, true);
        }

        private void RevertStock()
        {
            if (MessageBox.Show("Are you sure you want to revert all changes back to stock?\nSaves will not be touched.", "Confirm Revert", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            Log("Reverting files and driver profile...");
            string extra = "";
            if (!string.IsNullOrWhiteSpace(txtGamePath.Text))
                extra = "-GamePath " + Quote(txtGamePath.Text.Trim());
            bool ok = RunScript("Uninstall.ps1", extra, true);
            if (ok)
            {
                Log("Restored original files and reset driver profile. Saves were not changed.");
                MessageBox.Show("Cry of Fear restored back to stock vanilla.\nSaves were not rolled back.", "Reverted", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Revert finished with errors. See the log.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
