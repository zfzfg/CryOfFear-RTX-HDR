# Changelog

## 1.1.0 — 2026-09-12

Portable-only release. Fullscreen and RTX HDR Route 3B are unchanged.

### Fixed

- Texture filtering quality in `CryOfFear-HDR-Quality.nip` was `20`; High Quality is `4294967286` (`0xFFFFFFF6`).
- GUI and `INSTALL.bat` no longer invent a second `autoexec.cfg`. Both call `tools/Install.ps1`, which merges cvars into an existing file and keeps Cry of Fear 1.6 gameplay lines.
- GUI labelled fullscreen as "Borderless / DirectFlip". The label now matches `-fullscreen`. This build has no `-noborder` flag.
- NVIDIA Profile Inspector success was logged even if UAC was cancelled (`Process.Start` null) or the inspector exited non-zero.
- Double UAC: `INSTALL.bat` / `UNINSTALL.bat` no longer elevate the whole script. Only the inspector import requests admin.
- Independent AF checkbox did nothing (same NIP either way). 16x AF is part of the one quality profile.
- README promised Custom resolution; the GUI now has width/height fields plus Desktop native.

### Added

- Windows HDR is queried through DisplayConfig during install and diagnose. If HDR is off, install warns; diagnose `[FAIL]`s.
- Auto HDR is turned **off for `cof.exe` only** (`HKCU\...\UserGpuPreferences`, `AutoHDREnable=0`). Global Auto HDR and other games stay as they are. Uninstall removes that override.
- First-run backup of `SAVE/`, configs, and `black_fp.cg` under `backup/original`. Later installs never overwrite it. Uninstall does not restore saves.
- `tools/Common.ps1`, `Build-Config.ps1`, `Build-Portable.ps1`. Release zip is an allow-list (no `backup/`, no `.pdb`, no inspector profile dumps).

### Not changed

- Fullscreen launch options, Route 3B driver flags (`2`), MSAA off, `fps_max 100`, stock menu fonts.
